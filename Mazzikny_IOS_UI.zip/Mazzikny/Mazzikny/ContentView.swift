//
//  ContentView.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/21/21.
//

import SwiftUI
let greyColor = Color(red:239.0/255.0,green:243.0/255.0,blue:244.0/255.0)
struct ContentView: View {
    @State var email: String=""
    @State var password: String=""
    var body: some View {
    NavigationView{
        VStack{
            LogoLogin()
                
            EmailTextField(email: $email)
            PasswordTextField(password:$password)
                
            
            NavigationLink(destination:newHomePage()
                            .navigationBarTitle(Text("x"))
                            .navigationBarHidden(true)){
                Text("LOGIN")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 100, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .background(Color .black)
                    .cornerRadius(20.0)
                    .padding(.bottom,150)
            }
                
            
            
            
                NotaMemberText()
                
            NavigationLink(destination:SignUpPage()
                            .navigationBarTitle(Text("x"))
                            .navigationBarHidden(true)){
                Text("SIGN UP")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 100, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .background(Color .black)
                    .cornerRadius(20.0)
            }
            
            }
        
            
    }
    }
}
    
        


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct LogoLogin: View {
    var body: some View {
        Image("mazziknylogo")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 500, height: 300)
           // .padding(.top,40)
            }
}


struct NotaMemberText: View {
    var body: some View {
        Text("Not a member?")
            .padding(.bottom,30)
    }
}

struct EmailTextField: View {
    @Binding var email: String
    var body: some View {
        TextField("Email", text: $email)
            .padding()
            .background(greyColor)
            .cornerRadius(50.0)
            .padding(.bottom,10)
    }
}

struct PasswordTextField: View {
    @Binding var password: String
    var body: some View {
        SecureField("Password",text: $password)
            .padding()
            .background(greyColor)
            .cornerRadius(50.0)
            .padding(.bottom,10)
    }
}

