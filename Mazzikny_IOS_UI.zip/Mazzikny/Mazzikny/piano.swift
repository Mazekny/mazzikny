//
//  piano.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct piano: View {
    var body: some View {
        VStack{
            
         Image("piano")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 280, height: 280)
            .position(x: 200, y:150 )
            
        Text("Piano")
            .bold()
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            .position(x: 200, y:70 )
            
            Text("Price: 8000 EGP")
                .bold()
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .position(x: 200, y:-50 )
            Text("Notify Seller")
                .font(.headline)
                .foregroundColor(.white)
                .frame(width: 200, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(Color .black)
                .cornerRadius(20.0)
            }
    }
}

struct piano_Previews: PreviewProvider {
    static var previews: some View {
        piano()
    }
}
