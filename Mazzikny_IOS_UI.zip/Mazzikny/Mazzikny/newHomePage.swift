//
//  newHomePage.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct newHomePage: View {
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    Image("nosloganlogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .padding(.bottom,90)
                    Text("Home Page")
                        .bold()
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .padding(.bottom,30)
                }
        VStack{
            
            NavigationLink(destination:profile()
                            .navigationBarTitle(Text("Profile"))){
            Image("profile")//image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .padding(.leading,-30)
                .padding(.bottom,30)
                Text("Profile")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.black)
            }
            NavigationLink(destination:Store()
                            .navigationBarTitle(Text("Store"))){
            Image("store")//image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .padding(.leading,-50)
                .padding(.bottom,30)
                Text("Store")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.black)
                
            }
            NavigationLink(destination:Connections()
                            .navigationBarTitle(Text("Connections"))){
            Image("selectinstrument")//image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .padding(.bottom,30)
                .padding(.leading,50)
                Text("Connections")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.black)
            }
            NavigationLink(destination:ContentView()
                            .navigationBarTitle(Text("x"))
                            .navigationBarHidden(true)){
            Image("signout")//image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .padding()
                Text("Signout")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.black)
            }
            
            
        }.padding(.bottom,190)
        }
    }
}

struct newHomePage_Previews: PreviewProvider {
    static var previews: some View {
        newHomePage()
    }
}
}
