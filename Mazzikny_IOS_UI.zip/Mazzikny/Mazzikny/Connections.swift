//
//  Connections.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct Connections: View {
    var body: some View {
        
        List{
            HStack{
           Image("nosloganlogo")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 80, height: 80)
            .padding(.bottom,100)
            .padding(.leading,40)
                
            
            Text("Your Connections")
                .padding(.bottom,100)
                .padding(.leading,10)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                
            }
            
            NavigationLink(destination:AhmedRezk()){
            HStack{
                Image("man")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                Text("Ahmed Rezk")
                    .bold()
                    .font(.title)
                
            }
            }
            NavigationLink(destination:MohamedShenawy()){
            HStack{
                Image("man")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                Text("Mohamed El-Shenawy")
                    .bold()
                    .font(.title)
            }
            }
            NavigationLink(destination:MarwanAbbas()){
            HStack{
                Image("man")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                Text("Marwan Abbas")
                    .bold()
                    .font(.title)
            }
            }
            NavigationLink(destination:MohamedElNaggar()){
            HStack{
                Image("man")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                Text("Mohamed El-Naggar")
                    .bold()
                    .font(.title)
            }
            }
        }
    }
}

struct Connections_Previews: PreviewProvider {
    static var previews: some View {
        Connections()
    }
}
