//
//  MohamedElNaggar.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct MohamedElNaggar: View {
    var body: some View {
        VStack{
            Image("man")
            .resizable()
            .aspectRatio(contentMode: .fit)
            //.frame(width: 200, height: 200)
            .position(x: 200, y:150 )
            
            
        Text("Mohamed El-Naggar")
            .bold()
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
           // .padding(.bottom,20)
        Text("6 October, Egypt")
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            .padding(.bottom,50)
            
            ScrollView{
            List{
        Text("Email:")
            .fontWeight(.bold)
          //  .padding(.leading,-180)
            .font(.system(size: 20))
       
        Text("mohamed-elnaggar@aucegypt.edu")
           // .padding(.leading,-70)
            .font(.system(size: 20))
         //   .padding(.bottom,20)
            
            Text("Phone:")
                .fontWeight(.bold)
    //                .padding(.leading,-180)
               .font(.system(size: 20))
           
            Text("0123123124")
              //  .padding(.leading,-180)
                .font(.system(size: 20))
                //.padding(.bottom,20)
            
            Text("Facebook:")
                .fontWeight(.bold)
    //                .padding(.leading,-180)
                .font(.system(size: 20))
           
            Text("www.facebook.com/naggar/")
            //    .padding(.leading,-70)
                 .font(.system(size: 20))
    //                .padding(.bottom,20)
                
                Text("Video:")
                    .fontWeight(.bold)
    //                .padding(.leading,-180)
                    .font(.system(size: 20))
               
                Text("www.youtube.com/naggar/")
                //    .padding(.leading,-70)
                     .font(.system(size: 20))
    //                .padding(.bottom,20)
                
                Text("Instrument and Professionality:")
                    .fontWeight(.bold)
    //                .padding(.leading,-180)
                    .font(.system(size: 20))
               
                Text("Saxophone, Expert")
                //    .padding(.leading,-70)
                     .font(.system(size: 20))
    //                .padding(.bottom,20)


            }.frame(width: 400, height: 447, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)


        }.groupBoxStyle(/*@START_MENU_TOKEN@*/DefaultGroupBoxStyle()/*@END_MENU_TOKEN@*/)
            
        }
    }
}

struct MohamedElNaggar_Previews: PreviewProvider {
    static var previews: some View {
        MohamedElNaggar()
    }
}
