//
//  Store.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct Store: View {
    var body: some View {
        ScrollView(.vertical){
        VStack{
            
            
            HStack{
                Image("nosloganlogo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 100)
                    .padding(.bottom,30)
                Text("Store")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding(.bottom,30)
            }
            
            
            //first row
            List{
                    VStack{
                        NavigationLink(destination:drum()){
                        Image("drum")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,135)
                        }
                        Text("Drum")
                            .bold()
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .padding(.leading,20)
                        Text("Price: 2000 EGP")
                            .padding(.leading,20)
                        
                    }
                
                
                  
                    VStack{
                        NavigationLink(destination:flute()){
                        Image("flute")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,145)
                            
                        }
                        Text("Flute")
                            .bold()
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .padding(.leading,20)
                        Text("Price: 4000 EGP")
                            .padding(.leading,20)
                        }
                
            //first row
                    VStack{
                        NavigationLink(destination:Saxophone()){
                        Image("saxophone")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,105)
                        }
                        Text("Saxophone")
                            .bold()
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .padding(.leading,20)
                        Text("Price: 10000 EGP")
                            .padding(.leading,20)
                        //text
                        }
                    .padding()
                    VStack{
                        NavigationLink(destination:piano()){
                        Image("piano")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,135)
                        }
                        Text("Piano")
                            .bold()
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .padding(.leading,20)
                        Text("Price: 8000 EGP")
                            .padding(.leading,20)
                    }
            } .frame(width: 400, height: 740, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            }
                }
    }
        }

struct Store_Previews: PreviewProvider {
    static var previews: some View {
        Store()
    }
}
