//
//  flute.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct flute: View {
    var body: some View {
        VStack{
            
         Image("flute")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 280, height: 280)
            .position(x: 200, y:150 )
            
        Text("Flute")
            .bold()
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            .position(x: 200, y:70 )
            
            Text("Price: 4000 EGP")
                .bold()
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .position(x: 200, y:-50 )
            Text("Notify Seller")
                .font(.headline)
                .foregroundColor(.white)
                .frame(width: 200, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(Color .black)
                .cornerRadius(20.0)
            }
    }
}

    


struct flute_Previews: PreviewProvider {
    static var previews: some View {
        flute()
    }
}
