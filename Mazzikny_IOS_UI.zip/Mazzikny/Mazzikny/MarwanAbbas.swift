//
//  MarwanAbbas.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct MarwanAbbas: View {
    var body: some View {
        VStack{
            Image("man")
            .resizable()
            .aspectRatio(contentMode: .fit)
            //.frame(width: 200, height: 200)
            .position(x: 200, y:150 )
            
            
        Text("Marwan Abbas")
            .bold()
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
           // .padding(.bottom,20)
        Text("Maadi, Egypt")
            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            .padding(.bottom,50)
            
            ScrollView{
            List{
        Text("Email:")
            .fontWeight(.bold)
          //  .padding(.leading,-180)
            .font(.system(size: 20))
       
        Text("marwaneltouhky@aucegypt.edu")
           // .padding(.leading,-70)
            .font(.system(size: 20))
         //   .padding(.bottom,20)
            
            Text("Phone:")
                .fontWeight(.bold)
    //                .padding(.leading,-180)
               .font(.system(size: 20))
           
            Text("01111231231")
              //  .padding(.leading,-180)
                .font(.system(size: 20))
                //.padding(.bottom,20)
            
            Text("Facebook:")
                .fontWeight(.bold)
    //                .padding(.leading,-180)
                .font(.system(size: 20))
           
            Text("www.facebook.com/marwaneltouhky/")
            //    .padding(.leading,-70)
                 .font(.system(size: 20))
    //                .padding(.bottom,20)
                
                Text("Video:")
                    .fontWeight(.bold)
    //                .padding(.leading,-180)
                    .font(.system(size: 20))
               
                Text("www.youtube.com/marwaneltoukhy/")
                //    .padding(.leading,-70)
                     .font(.system(size: 20))
    //                .padding(.bottom,20)
                
                Text("Instrument and Professionality:")
                    .fontWeight(.bold)
    //                .padding(.leading,-180)
                    .font(.system(size: 20))
               
                Text("Violin, Beginner")
                //    .padding(.leading,-70)
                     .font(.system(size: 20))
    //                .padding(.bottom,20)


            }.frame(width: 400, height: 447, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)


        }.groupBoxStyle(/*@START_MENU_TOKEN@*/DefaultGroupBoxStyle()/*@END_MENU_TOKEN@*/)
            
        }
        
    }
}

struct MarwanAbbas_Previews: PreviewProvider {
    static var previews: some View {
        MarwanAbbas()
    }
}
