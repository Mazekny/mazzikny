//
//  SignUpPage.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct SignUpPage: View {
    @State var email: String=""
    @State var password: String=""
    @State var name: String=""
    @State var number: String=""
    @State var location: String=""
    @State var instrument: String=""
    @State var expYears: String=""
    @State var facebookURL: String=""
    @State var twitterURL: String=""
    @State var videoURL: String=""
    var body: some View {
    
        ScrollView(.vertical){
        VStack{
            Group{
            Logo()
            TextField("Enter First and Last name", text: $name)
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            EmailText(email: $email)
            PasswordText(password:$password)
            TextField("Phone Number", text: $email)
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            TextField("Enter Location", text:$location )
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            TextField("Enter Instrument", text: $instrument)
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
                
            }
            TextField("Enter Experience Years", text: $expYears)
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            TextField("Enter your Facebook URL", text: $facebookURL )
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            TextField("Enter your Twitter URL", text: $twitterURL)
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            TextField("Enter your Video URL", text: $videoURL)
                .padding()
                .background(greyColor)
                .cornerRadius(50.0)
                .padding(.bottom,10)
            
            
            
            NavigationLink(destination:ContentView()
                            .navigationBarTitle(Text("x"))
                            .navigationBarHidden(true)){
                Text("SIGNUP")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 100, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .background(Color .black)
                    .cornerRadius(20.0)
            }
                
            
            
            
                haveAccount()
                
            NavigationLink(destination:ContentView()
                            .navigationBarTitle(Text("x"))
                            .navigationBarHidden(true)){
                Text("Click here")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 100, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .background(Color .black)
                    .cornerRadius(20.0)
            }
            
            
      
        }
            
    }
    }
}
    
struct SignUpPage_Previews: PreviewProvider {
    static var previews: some View {
        SignUpPage()
    }
}

struct Logo: View {
    var body: some View {
        Image("mazziknylogo")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 200, height: 200)
           // .padding(.top,40)
            }
}


struct haveAccount: View {
    var body: some View {
        Text("Already have an account?")
            .padding(.bottom,10)
    }
}

struct EmailText: View {
    @Binding var email: String
    var body: some View {
        TextField("Email", text: $email)
            .padding()
            .background(greyColor)
            .cornerRadius(50.0)
            .padding(.bottom,10)
    }
}

struct PasswordText: View {
    @Binding var password: String
    var body: some View {
        SecureField("Password",text: $password)
            .padding()
            .background(greyColor)
            .cornerRadius(50.0)
            .padding(.bottom,10)
    }
}

