//
//  HomePage.swift
//  Mazzikny
//
//  Created by Salma Helal on 1/22/21.
//

import SwiftUI

struct HomePage: View {
    var body: some View {
        
        //NavigationView{
        VStack{
            HStack{
                Image("nosloganlogo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 100)
                    .padding(.bottom,30)
                Text("Home Page")
                    .bold()
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding(.bottom,30)
            }
            
            
            List{
                HStack{ //first row
                    VStack{
                        //NavigationView{
                        NavigationLink(destination:profile()
                                        .navigationBarTitle(Text("HomePage"))){
                        Image("profile")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                        Text("Profile")
                            .bold()
                            .padding(.bottom,30)
                        }.navigationViewStyle(StackNavigationViewStyle())
                        
                    }
                    .padding()
                    VStack{
                        NavigationLink(destination:ContentView()
                                        .navigationBarTitle(Text("x"))){
                        Image("search")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,40)
                        }
                        Text("Search")
                            .bold()
                           // .padding(.bottom,30)
                            .padding(.leading,40)
                        
     
                    }
                }
                HStack{ //Second row
                    NavigationLink(destination:Store()
                                    .navigationBarTitle(Text("HomePage"))){
                    VStack{
                        
                        Image("store")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                        Text("Store")
                            .bold()
                            .padding(.bottom,30)
                        }
                    }.navigationViewStyle(StackNavigationViewStyle())
                    .padding()
                    NavigationLink(destination:ContentView()
                                    .navigationBarTitle(Text("x"))){
                    VStack{
                        Image("selectinstrument")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,40)
                        Text("Connections")
                            .bold()
                            .padding(.leading,40)
                            .padding(.bottom,30)
                        }
     
                    }.navigationViewStyle(StackNavigationViewStyle())
                }
                HStack{ //first row
                    NavigationLink(destination:SignUpPage()
                                    .navigationBarTitle(Text("x"))){
                    VStack{
                        
                        Image("about")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                        Text("About")
                            .bold()
                            .padding(.bottom,30)
                        }
                    }.navigationViewStyle(StackNavigationViewStyle())
                    .padding()
                    NavigationLink(destination:ContentView()
                                    .navigationBarTitle(Text("x"))){
                    VStack{
                        Image("signout")//image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding(.leading,40)
                        Text("Sign-Out")
                            .bold()
                            .padding(.bottom,30)
                            .padding(.leading,40)
                        }
     
                    }.navigationViewStyle(StackNavigationViewStyle())
                }
                
            }
                
                
            }
            }
        
        
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
